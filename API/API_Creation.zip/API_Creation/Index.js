const fs = require("fs");
const http = require("http");

const server = http.createServer((req , res)=>{
    if(req.url == "/"){
       res.end("Pranjal")
    }else if(req.url == "/API"){
        fs.readFile("API.JSON","utf-8",(err,data)=>{
            res.end(data) 
            const objData =JSON.parse(data);
            res.end(objData[0].name);
        })
    }
});

server.listen(8000,"127.0.0.1",()=>{
    console.log("Listeningt to the port 8000")
})