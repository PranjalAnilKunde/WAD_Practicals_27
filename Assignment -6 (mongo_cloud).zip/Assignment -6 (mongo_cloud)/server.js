const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://kbtug20210:divya147@cluster0.2big9zy.mongodb.net/?retryWrites=true&w=majority').then(() => console.log('Connected!'));